﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Activity_2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void c1_Checked(object sender, RoutedEventArgs e)
        {
            t1.Text = "two states checked";
            
        }
        
        private void c1_notchecked(object sender ,RoutedEventArgs e)
        {
            t1.Text = " two ststes unchecked";
        }

        private void c2_Checked(object sender, RoutedEventArgs e)
        {
            t2.Text = "three states checked";

        }

        private void c2_notchecked(object sender, RoutedEventArgs e)
        {
            t2.Text = "three states unchecked";
        }

        private void c2_indeterm(object sender, RoutedEventArgs e)
        {
            t2.Text = "indeteminate state";
        }
    }
}
